# My Package

A brief description of what your package does.

## Installation

```bash
pip install my_package