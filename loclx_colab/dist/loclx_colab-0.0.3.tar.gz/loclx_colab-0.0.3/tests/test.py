
from loclx_colab import http_tunnel,login

http_tunnel(port=1234,access_token="8jfZMBrtwnZXjZwrujAzU7jBkTYxIhunXwSmflDy")
